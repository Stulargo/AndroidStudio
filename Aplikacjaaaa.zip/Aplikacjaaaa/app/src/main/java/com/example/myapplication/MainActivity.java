package com.example.myapplication;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private boolean isXTurn = true;
    private Button[] buttons = new Button[9];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int[] buttonIds = {
                R.id.button1, R.id.button2, R.id.button3,
                R.id.button4, R.id.button5, R.id.button6,
                R.id.button7, R.id.button8, R.id.button9
        };

        for (int i = 0; i < buttonIds.length; i++) {
            buttons[i] = findViewById(buttonIds[i]);
            buttons[i].setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Button btn = (Button) v;
                    if (btn.getText().toString().isEmpty()) {
                        btn.setText(isXTurn ? "X" : "O");
                        btn.setEnabled(false);
                        int[] winningIndices = checkWin();
                        if (winningIndices != null) {
                            disableAllButtons();
                        } else if (isBoardFull()) {

                        } else {
                            isXTurn = !isXTurn;
                        }
                    }
                }
            });
        }

        Button resetButton = findViewById(R.id.resetButton);
        resetButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetGame();
            }
        });
    }

    private int[] checkWin() {
        String[] board = new String[9];
        for (int i = 0; i < 9; i++) {
            board[i] = buttons[i].getText().toString();
        }

        for (int i = 0; i < 9; i += 3) {
            if (!board[i].isEmpty() && board[i].equals(board[i + 1]) && board[i].equals(board[i + 2])) {
                buttons[i].setBackgroundColor(Color.parseColor("#00FF00"));
                buttons[i + 1].setBackgroundColor(Color.parseColor("#00FF00"));
                buttons[i + 2].setBackgroundColor(Color.parseColor("#00FF00"));
                return new int[]{i, i + 1, i + 2};
            }
        }

        for (int i = 0; i < 3; i++) {
            if (!board[i].isEmpty() && board[i].equals(board[i + 3]) && board[i].equals(board[i + 6])) {
                buttons[i].setBackgroundColor(Color.parseColor("#00FF00"));
                buttons[i + 3].setBackgroundColor(Color.parseColor("#00FF00"));
                buttons[i + 6].setBackgroundColor(Color.parseColor("#00FF00"));
                return new int[]{i, i + 3, i + 6};
            }
        }

        if (!board[0].isEmpty() && board[0].equals(board[4]) && board[0].equals(board[8])) {
            buttons[0].setBackgroundColor(Color.parseColor("#00FF00"));
            buttons[4].setBackgroundColor(Color.parseColor("#00FF00"));
            buttons[8].setBackgroundColor(Color.parseColor("#00FF00"));
            return new int[]{0, 4, 8};
        }
        if (!board[2].isEmpty() && board[2].equals(board[4]) && board[2].equals(board[6])) {
            buttons[2].setBackgroundColor(Color.parseColor("#00FF00"));
            buttons[4].setBackgroundColor(Color.parseColor("#00FF00"));
            buttons[6].setBackgroundColor(Color.parseColor("#00FF00"));
            return new int[]{2, 4, 6};
        }

        return null;
    }

    private boolean isBoardFull() {
        for (Button button : buttons) {
            if (button.getText().toString().isEmpty()) {
                return false;
            }
        }
        return true;
    }

    private void disableAllButtons() {
        for (Button button : buttons) {
            button.setEnabled(false);
        }
    }

    private void resetGame() {
        for (Button button : buttons) {
            button.setText("");
            button.setEnabled(true);
            button.setBackgroundResource(R.drawable.button_selector);
        }
        isXTurn = true;
    }
}