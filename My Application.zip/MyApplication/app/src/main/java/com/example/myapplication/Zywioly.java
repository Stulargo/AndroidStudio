package com.example.myapplication;

import java.util.ArrayList;
import java.util.List;

public class Zywioly {

    public List<String> getPokemons(String zywiol) {
        List<String> pokemons = new ArrayList<>();

        if (zywiol.equals("Ogień")) {
            pokemons.add("Charmander");
            pokemons.add("Vulpix");
            pokemons.add("Growlithe");
        } else if (zywiol.equals("Woda")) {
            pokemons.add("Squirtle");
            pokemons.add("Psyduck");
            pokemons.add("Poliwag");
        } else if (zywiol.equals("Ziemia")) {
            pokemons.add("Sandshrew");
            pokemons.add("Diglett");
            pokemons.add("Geodude");
        } else if (zywiol.equals("Elektryczność")) {
            pokemons.add("Pikachu");
            pokemons.add("Magnemite");
            pokemons.add("Electabuzz");
        }

        return pokemons;
    }
}
