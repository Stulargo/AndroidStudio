package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Spinner spinner;
    private TextView textPokemons;
    private Zywioly zywioly;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        spinner = findViewById(R.id.spinner);
        textPokemons = findViewById(R.id.textPokemons);
        Button buttonFind = findViewById(R.id.button_find);

        zywioly = new Zywioly();

        textPokemons.setText(getString(R.string.zywioly));

        buttonFind.setOnClickListener(v -> onClickFindPokemons());
    }

    private void onClickFindPokemons() {
        String selected = spinner.getSelectedItem().toString();
        List<String> pokemons = zywioly.getPokemons(selected);

        if (pokemons.isEmpty()) {
            textPokemons.setText(getString(R.string.zywioly));
        } else {
            StringBuilder sb = new StringBuilder();
            for (String p : pokemons) {
                sb.append(p).append("\n");
            }
            textPokemons.setText(sb.toString().trim());
        }
    }
}
